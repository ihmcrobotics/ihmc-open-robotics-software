package org.ros.internal.node.service;

enum ServiceResponseDecoderState {
  ERROR_CODE, MESSAGE_LENGTH, MESSAGE
}