package urbanwarrior.controllers;

import com.mathworks.jama.Matrix;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2004</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class FullKalman
{
   static final int N = 7;
   static final int m = 3;

   // Covariance matrix
   Matrix P = new Matrix(N, N);
   // Noise estimate
   Matrix Q = new Matrix(N, N);
   // State estimate for angles
   Matrix R_attitude = new Matrix(m, m);

   Matrix accel = new Matrix(m,1);
   Matrix theta = new Matrix(m,1);
   Matrix pqr = new Matrix(m,1);
   Matrix bias = new Matrix(m,1);
   Matrix q = new Matrix(4,1);

   double dt = .001;
   double trace;
   static final double PI = Math.PI;
   static final boolean verbose = false;

   /*
    *  Our Kalman filter uses its own state object that we
    * hide here.
    */
   class state_t
   {
      public Matrix q; // = new Matrix(4,1); // Quaternion state estimate
      public Matrix bias; // = new Matrix(3,1); // Gyro bias estimate
   };
   state_t state = new state_t();

   Matrix C = new Matrix(3, N);
   Matrix Ct, E;

   public FullKalman(double dt) {
      this.dt = dt;
      reset();
   }

   /*
    * This will construct a direction cosine matrix from
    * euler angles in the standard rotation sequence
    * [phi][theta][psi] from NED to body frame
    *
    * body = tBL(3,3)*NED
    */
   Matrix eulerDC(Matrix euler) {
      double phi = euler.get(0, 0);
      double theta = euler.get(0, 1);
      double psi = euler.get(0, 2);

      double cpsi = Math.cos(psi);
      double cphi = Math.cos(phi);
      double ctheta = Math.cos(theta);

      double spsi = Math.sin(psi);
      double sphi = Math.sin(phi);
      double stheta = Math.sin(theta);

      Matrix M = new Matrix(3, 3);
      M.set(0, 0, cpsi * ctheta);
      M.set(0, 1, spsi * ctheta);
      M.set(0, 2, -stheta);
      M.set(1, 0, -spsi * cphi + cpsi * stheta * sphi);
      M.set(1, 1, cpsi * cphi + spsi * stheta * sphi);
      M.set(1, 2, ctheta * sphi);
      M.set(2, 0, spsi * sphi + cpsi * stheta * cphi);
      M.set(2, 1, -cpsi * sphi + spsi * stheta * cphi);
      M.set(2, 2, ctheta * cphi);
      return M;
   }

   /*
    * This will construct a direction cosine matrix from
    * quaternions in the standard rotation  sequence
    * [phi][theta][psi] from NED to body frame
    *
    * body = tBL(3,3)*NED
    * q(4,1)
    */
   Matrix quatDC(Matrix q) {
      double q0 = q.get(0,0);
      double q1 = q.get(1,0);
      double q2 = q.get(2,0);
      double q3 = q.get(3,0);

      Matrix M = new Matrix(3, 3);
      M.set(0, 0, 1.0 - 2 * (q2 * q2 + q3 * q3));
      M.set(0, 1, 2 * (q1 * q2 + q0 * q3));
      M.set(0, 2, 2 * (q1 * q3 - q0 * q2));
      M.set(1, 0, 2 * (q1 * q2 - q0 * q3));
      M.set(1, 1, 1.0 - 2 * (q1 * q1 + q3 * q3));
      M.set(1, 2, 2 * (q2 * q3 + q0 * q1));
      M.set(2, 0, 2 * (q1 * q3 + q0 * q2));
      M.set(2, 1, 2 * (q2 * q3 - q0 * q1));
      M.set(2, 2, 1.0 - 2 * (q1 * q1 + q2 * q2));
      return M;
   }

   /*
    * This will construct the euler omega-cross matrix
    * wx(3,3)
    * p, q, r (rad/sec)
    */
   Matrix eulerWx(Matrix euler) {
      double p = euler.get(0,0);
      double q = euler.get(1,0);
      double r = euler.get(2,0);

      Matrix M = new Matrix(3,3);
      M.set(0, 0, 0);
      M.set(0, 1, -r);
      M.set(0, 2, q);
      M.set(1, 0, r);
      M.set(1, 1, 0);
      M.set(1, 2, -p);
      M.set(2, 0, -q);
      M.set(2, 1, p);
      M.set(2, 2, 0);
      return M;
   }

   /*
    * This will construct the quaternion omega matrix
    * W(4,4)
    * p, q, r (rad/sec)
    */
   Matrix quatW(Matrix euler) {
      double p = euler.get(0,0) / 2.0;
      double q = euler.get(1,0) / 2.0;
      double r = euler.get(2,0) / 2.0;

      Matrix M = new Matrix(4, 4);

      M.set(0, 0, 0);
      M.set(0, 1, -p);
      M.set(0, 2, -q);
      M.set(0, 3, -r);

      M.set(1, 0, p);
      M.set(1, 1, 0);
      M.set(1, 2, r);
      M.set(1, 3, -q);

      M.set(2, 0, q);
      M.set(2, 1, -r);
      M.set(2, 2, 0);
      M.set(2, 3, p);

      M.set(3, 0, r);
      M.set(3, 1, q);
      M.set(3, 2, -p);
      M.set(3, 3, 0);
      return M;
   }

   /*
    * This will convert from quaternions to euler angles
    * q(4,1) -> euler[phi;theta;psi] (rad)
    */
   Matrix quat2euler(Matrix q) {
      double q0 = q.get(0,0);
      double q1 = q.get(1,0);
      double q2 = q.get(2,0);
      double q3 = q.get(3,0);

      double theta = -Math.asin(2 * (q1 * q3 - q0 * q2));
      double phi = Math.atan2(2 * (q2 * q3 + q0 * q1), 1 - 2 * (q1 * q1 + q2 * q2));
      double psi = Math.atan2(2 * (q1 * q2 + q0 * q3), 1 - 2 * (q2 * q2 + q3 * q3));

      Matrix euler = new Matrix(3,1);
      euler.set(0,0, phi);
      euler.set(1,0, theta);
      euler.set(2,0, psi);
      return euler;
   }

   /*
    * This will convert from euler angles to quaternion vector
    * phi, theta, psi -> q(4,1)
    * euler angles in radians
    */
   Matrix euler2quat(Matrix euler) {
      double phi = euler.get(0,0) / 2.0;
      double theta = euler.get(1,0) / 2.0;
      double psi = euler.get(2,0) / 2.0;

      double shphi0 = Math.sin(phi);
      double chphi0 = Math.cos(phi);

      double shtheta0 = Math.sin(theta);
      double chtheta0 = Math.cos(theta);

      double shpsi0 = Math.sin(psi);
      double chpsi0 = Math.cos(psi);

      Matrix quat = new Matrix(4,1);
      quat.set(0,0, chphi0 * chtheta0 * chpsi0 + shphi0 * shtheta0 * shpsi0);
      quat.set(1,0, -chphi0 * shtheta0 * shpsi0 + shphi0 * chtheta0 * chpsi0);
      quat.set(2,0, chphi0 * shtheta0 * chpsi0 + shphi0 * chtheta0 * shpsi0);
      quat.set(3,0, chphi0 * chtheta0 * shpsi0 - shphi0 * shtheta0 * chpsi0);
      return quat;
   }

   /*
    * Functions to compute the partial derivative of the quaterion with
    * respect to the Euler angles.  These are used for computation of the
    * matrix C in the Kalman filter that represents the relationship of
    * the measurements to the states.
    */
   Matrix dphi_dq(Matrix quat, Matrix DCM) {
      double q0 = quat.get(0,0);
      double q1 = quat.get(1,0);
      double q2 = quat.get(2,0);
      double q3 = quat.get(3,0);
      double dcm22 = DCM.get(2, 2);
      double dcm12 = DCM.get(1, 2);
      double err = 2 / (dcm22 * dcm22 + dcm12 * dcm12);

      Matrix ret = new Matrix(4,1);
      ret.set(0,0, (q1 * dcm22) * err);
      ret.set(1,0, (q0 * dcm22 + 2 * q1 * dcm12) * err);
      ret.set(2,0, (q3 * dcm22 + 2 * q2 * dcm12) * err);
      ret.set(3,0, (q2 * dcm22) * err);
      return ret;
   }

   Matrix dtheta_dq(Matrix quat, Matrix DCM) {
      double q0 = quat.get(0,0);
      double q1 = quat.get(1,0);
      double q2 = quat.get(2,0);
      double q3 = quat.get(3,0);
      double dcm02 = DCM.get(0,2);
      double err = -2 / Math.sqrt(1 - dcm02 * dcm02);

      Matrix ret = new Matrix(4,1);
      ret.set(0, 0, -q2 * err);
      ret.set(1, 0, q3 * err);
      ret.set(2, 0, -q0 * err);
      ret.set(3, 0, q1 * err);
      return ret;
   }

   Matrix dpsi_dq(Matrix quat, Matrix DCM) {
      double q0 = quat.get(0, 0);
      double q1 = quat.get(1,0);
      double q2 = quat.get(2,0);
      double q3 = quat.get(3,0);
      double dcm00 = DCM.get(0, 0);
      double dcm01 = DCM.get(0, 1);
      double err = 2 / (dcm00 * dcm00 + dcm01 * dcm01);

      Matrix ret = new Matrix(4,1);
      ret.set(0,0, err * (q3 * dcm00));
      ret.set(1,0, err * (q2 * dcm00));
      ret.set(2,0, err * (q1 * dcm00 + 2 * q2 * dcm01));
      ret.set(3,0, err * (q0 * dcm00 + 2 * q3 * dcm01));
      return ret;
   }

   void make_a_matrix(Matrix A, Matrix pqr) {
      state_t x = this.state;
      Matrix Wxq = quatW(pqr);

      /*
       * A[0..4][0..4] is the partials of d(Qdot) / d(Q),
       * which is the Body rates euler cross.
       */
      A.set(0, 0, Wxq.get(0, 0));
      A.set(0, 1, Wxq.get(0, 1));
      A.set(0, 2, Wxq.get(0, 2));
      A.set(0, 3, Wxq.get(0, 3));

      A.set(1, 0, Wxq.get(1, 0));
      A.set(1, 1, Wxq.get(1, 1));
      A.set(1, 2, Wxq.get(1, 2));
      A.set(1, 3, Wxq.get(1, 3));

      A.set(2, 0, Wxq.get(2, 0));
      A.set(2, 1, Wxq.get(2, 1));
      A.set(2, 2, Wxq.get(2, 2));
      A.set(2, 3, Wxq.get(2, 3));

      A.set(3, 0, Wxq.get(3, 0));
      A.set(3, 1, Wxq.get(3, 1));
      A.set(3, 2, Wxq.get(3, 2));
      A.set(3, 3, Wxq.get(3, 3));

      /*
       * A[0..3][4..6] is the partials of d(Qdot) / d(Gyro_bias)
       * Qdot = quatW( pqr - gyro_bias) * Q
       */
      double q0 = x.q.get(0,0) / 2.0;
      double q1 = x.q.get(1,0) / 2.0;
      double q2 = x.q.get(2,0) / 2.0;
      double q3 = x.q.get(3,0) / 2.0;

      A.set(0, 4, q1); // d(q0_dot) / d(P_bias)
      A.set(0, 5, q2); // d(q0_dot) / d(P_bias)
      A.set(0, 6, q3); // d(q0_dot) / d(P_bias)

      A.set(1, 4, -q0); // d(q1_dot) / d(P_bias)
      A.set(1, 5, q3); // d(q1_dot) / d(Q_bias)
      A.set(1, 6, -q2); // d(q1_dot) / d(R_bias)

      A.set(2, 4, -q3); // d(q2_dot) / d(P_bias)
      A.set(2, 5, -q0); // d(q2_dot) / d(Q_bias)
      A.set(2, 6, q1); // d(q2_dot) / d(R_bias)

      A.set(3, 4, q2); // d(q3_dot) / d(P_bias)
      A.set(3, 5, -q1); // d(q3_dot) / d(Q_bias)
      A.set(3, 6, -q0); // d(q3_dot) / d(R_bias)

      /*
       * A[4..6][0..3] is the partials of d(Gyro_bias_dot)/d(Q)
       * which is zero.
       *
       * A[4..6][4..6] is the partials of d(Gyro_bias_dot)/d(Gyro_bias)
       * which is also zero.
       */
      for(int i = 4; i < N; i++)
         for(int j = 0; j < N; j++)
            A.set(i, j, 0);
   }

   void normalize(double[] v) {
      double mag = 0;
      for(int i = 0; i < v.length; i++)
         mag += v[i] * v[i];
      mag = Math.sqrt(mag);
      for(int i = 0; i < v.length; i++)
         v[i] /= mag;
   }

   void normalize(Matrix M) {
      double mag = 0;
      double s;
      int m = M.getRowDimension(), n = M.getColumnDimension();
      for(int i = 0; i < m; i++)
         for(int j = 0; j < n; j++)
         {
            s = M.get(i, j);
            mag += s * s;
         }
      mag = Math.sqrt(mag);
      for(int i = 0; i < m; i++)
         for(int j = 0; j < n; j++)
            M.set(i, j, M.get(i, j) / mag);
   }

   /*
    * Our state update function for the IMU is:
    *
    * Qdot = Wxq * Q
    * bias_dot = [0,0,0]
    * Q += Qdot * dt
    */
   void propagate_state(Matrix pqr) {
      state_t x = this.state;
      Matrix Wxq = quatW(pqr);
      Matrix Qdot = Wxq.times(x.q); // = Wxq * x.q;

      // const double[]<3>	bias_dot( 0, 0, 0 );

      if(verbose)
         System.out.println("propagating state: pqr = " + pqr);

      x.q.plusEquals(Qdot.times(this.dt)); //+= Qdot * this->dt;
      normalize(x.q);
      this.q = x.q;
   }

   void propagate_covariance(Matrix A) {
      Matrix Pdot = Q.copy();
      Pdot.plusEquals(A.times(P)); // += A * this->P;
      Pdot.plusEquals(P.times(A.transpose())); // += this->P * A.transpose();
      Pdot.timesEquals(dt); // *= this->dt;
      P.plusEquals(Pdot); //+= Pdot;
      trace = P.trace();
   }

   // Matrix<7,7> P, Matrix X, Matrix<3,7> C, Matrix R, Matrix err, Matrix K) {
   void Kalman(Matrix P, Matrix X, Matrix C, Matrix R, Matrix err, Matrix K) {
      Ct = C.transpose();
      E = C.times(P).times(Ct).plus(R); //   E = C*P*Ct+R
      K = P.times(Ct).times(E.inverse()); // K = P*Ct*inv(E)
      X.plusEquals(K.times(err)); //         X += K*err;
      P.minusEquals(K.times(C).times(P)); // P -= K*C*P;
   }

//   void do_kalman(Matrix<3,N> C, Matrix<3,3> R, Matrix<1,3> error, int m=3) {
   void do_kalman(Matrix C, Matrix R, Matrix error) {
      state_t x = this.state;

      // We throw away the K result
      Matrix K = new Matrix(N, 3);

      // Kalman() wants a vector, not an object.  Serialize the
      // state data into this vector, then extract it out again
      // once we're done with the loop.
      Matrix X_vect = new Matrix(N,1);

      X_vect.set(0,0, x.q.get(0,0));
      X_vect.set(1,0, x.q.get(1,0));
      X_vect.set(2,0, x.q.get(2,0));
      X_vect.set(3,0, x.q.get(3,0));

      X_vect.set(4,0, x.bias.get(0,0));
      X_vect.set(5,0, x.bias.get(1,0));
      X_vect.set(6,0, x.bias.get(2,0));

      Kalman(P, X_vect, C, R, error, K);

      x.q.set(0,0, X_vect.get(0,0));
      x.q.set(1,0, X_vect.get(1,0));
      x.q.set(2,0, X_vect.get(2,0));
      x.q.set(3,0, X_vect.get(3,0));
      normalize(x.q);

      x.bias.set(0,0, X_vect.get(4,0));
      x.bias.set(1,0, X_vect.get(5,0));
      x.bias.set(2,0, X_vect.get(6,0));

      // Copy out our user-visible variables
      theta = quat2euler(x.q);
      bias = x.bias;
      q = x.q;
   }

   void reset() {
      /*
       * The covariance matrix is probably initialized incorrectly.
       * It should be 1 for all diagonal elements of Q that are 0
       * and zero everywhere else.
       */
      //this->P			= eye<N,double>();
      zero(this.P);
      P.set(0, 0, 1);
      P.set(1, 1, 1);
      P.set(2, 2, 1);
      P.set(3, 3, 1);

      zero(this.Q);
      zero(this.R_attitude);

      // Quaternion attitude estimate noise
      // Since we have only one way to measure it, we set it
      // to zero.
      this.Q.set(0, 0, 0.0);
      this.Q.set(1, 1, 0.0);
      this.Q.set(2, 2, 0.0);
      this.Q.set(3, 3, 0.0);

      // Gyro bias estimate noise
      this.Q.set(4, 4, 0.05 * 0.05);
      this.Q.set(5, 5, 0.05 * 0.05);
      this.Q.set(6, 6, 0.05 * 0.05);

      // Measurement estimate noise.  Our heading is likely
      // to have more noise than the pitch and roll angles.
      this.R_attitude.set(0, 0, 25.3 * 25.3);
      this.R_attitude.set(1, 1, 25.3 * 25.3);
      this.R_attitude.set(2, 2, 28.5 * 28.5);
   }

   /*
    * We assume that the vehicle is still during the first sample
    * and use the values to help us determine the zero point for the
    * gyro bias and accelerometers.
    *
    * You must call this once you have the samples from the IMU
    * and compass.  Perhaps throw away the first few to let things
    * stabilize.
    */
   void initialize(Matrix accel, Matrix pqr, double heading) {
      state.bias = pqr;
      bias = pqr;
      theta = accel2euler(accel, heading);
      state.q = euler2quat(theta);
   }

   void imu_update(Matrix pqr_raw) {
      state_t x = state;
      Matrix pqr = pqr_raw.minus(x.bias);
      Matrix A = new Matrix(N, N);

      make_a_matrix(A, pqr);
      propagate_state(pqr);
      propagate_covariance(A);

      /* compute angles from quaternions */
      theta = quat2euler(x.q);

      /* Store our bias and converted angular rates */
      this.pqr = pqr;
   }

   /*
    * Determine the shortest distance between two euler angles.
    * This might involve wrapping the other way around the circle.
    * You must have called compute_euler() to produce the euler
    * attitude estimate before calling this.
    */

   Matrix euler_diff(Matrix euler_m, Matrix euler) {
      Matrix diff = new Matrix(3,1);
      diff.set(0,0, euler_m.get(0,0) - euler.get(0,0));
      diff.set(1,0, euler_m.get(1,0) - euler.get(1,0));
      diff.set(2,0, euler_m.get(2,0) - euler.get(2,0));

      /* Roll angles go from -180 degs to +180 degs */
      double d = diff.get(0, 0);
      if(d < -PI)
         diff.set(0, 0, d + 2 * PI);
      else if(d > PI)
         diff.set(0, 0, d - 2 * PI);

      /* Pitch angles only go +/- 90 degs */
      d = diff.get(1,0);
      if(d > PI / 2)
         diff.set(1,0, d - PI);
      if(d < -PI / 2)
         diff.set(1,0, d + PI);

      /* Heading is +/- 180 degs */
      d = diff.get(2,0);
      if(d > PI)
         diff.set(2,0, d - 2 * PI);
      if(d < -PI)
         diff.set(2,0, d + 2 * PI);
      return diff;
   }

   void compass_update(double heading, Matrix accel) {
      this.accel = accel;
      state_t x = this.state;

      // Compute our measured and estimated angles
      Matrix angles_m = accel2euler(accel, heading);
      Matrix angles_e = quat2euler(x.q);

      // Compute the error between our measurement and our estimate
      Matrix error = euler_diff(angles_m, angles_e);

      /*
       * Compute our C matrix, which relates the quaternion state
       * estimate to the angles measured by the accelerometers and
       * the compass.  The other states are all zero.
       */

      // Compute the DCM of our quaternion estimate
      Matrix DCM = quatDC(x.q); //see Quat.h....
      Matrix dphi = dphi_dq(x.q, DCM);
      Matrix dtheta = dtheta_dq(x.q, DCM);
      Matrix dpsi = dpsi_dq(x.q, DCM);

      // PHI section.  How does
      C.set(0, 0, dphi.get(0,0));
      C.set(0, 1, dphi.get(1,0));
      C.set(0, 2, dphi.get(2,0));
      C.set(0, 3, dphi.get(3,0));

      // THETA section
      C.set(1, 0, dtheta.get(0,0));
      C.set(1, 1, dtheta.get(1,0));
      C.set(1, 2, dtheta.get(2,0));
      C.set(1, 3, dtheta.get(3,0));

      // PSI section
      C.set(2, 0, dpsi.get(0,0));
      C.set(2, 1, dpsi.get(1,0));
      C.set(2, 2, dpsi.get(2,0));
      C.set(2, 3, dpsi.get(3,0));

      if(verbose)
         System.out.println("compass_update:" + " m = " + angles_m + " e = " + angles_e + " err = " + error);

      do_kalman(C, this.R_attitude, error);
   }

   void zero(Matrix a) {
      for(int i = 0; i < a.getRowDimension(); i++)
         for(int j = 0; j < a.getColumnDimension(); j++)
            a.set(i, j, 0.0);
   }

   /**
    *  Convert accelerations to euler angles
    */
   double mag(Matrix a) {
      double ret = 0.0;
      for(int i = 0; i < a.getRowDimension(); i++)
         for(int j = 0; j < a.getColumnDimension(); j++)
            ret += a.get(i, j) * a.get(i, j);
      return Math.sqrt(ret);
   }

   Matrix accel2euler(Matrix a, double heading) {
      double g = mag(a);
      Matrix ret = new Matrix(3,1);
      ret.set(0,0, -Math.atan2(a.get(1,0), -a.get(2,0))); // Roll
      ret.set(1,0, -Math.asin(a.get(0, 0) / -g)); //           Pitch
      ret.set(2,0, heading); //                                Yaw
      return ret;
   }

   /*
    * Find the shortest distance around the circle from psi to desired.
    * Otherwise our controllers will have problems facing south.
    *
    * THIS IS DEPRECATED.  Use turn_direction instead.
    */
   double smallest_angle(double psi, double desired) {
      if(desired - psi > PI)
         return psi + 2 * PI;

      if(psi - desired > PI)
         return psi - 2 * PI;

      return psi;
   }

   /*
    * Compute the shortest way from the current position to the
    * commanded position.  Both are in radians.
    */
   double turn_direction(double command, double current) {
      if(current > PI / 2 && command < -PI / 2)
         return 2 * PI + command - current;
      if(current < -PI / 2 && command > PI / 2)
         return -2 * PI + command - current;
      return command - current;
   }

   Matrix euler_strapdown(Matrix euler) {
      double sphi = Math.sin(euler.get(0,0));
      double cphi = Math.cos(euler.get(0,0));
      double ctheta = Math.cos(euler.get(1,0));
      double ttheta = Math.tan(euler.get(1,0));

      Matrix ret = new Matrix(3, 3);
      ret.set(0, 0, 1);
      ret.set(0, 1, sphi * ttheta);
      ret.set(0, 2, cphi * ttheta);
      ret.set(1, 0, 0);
      ret.set(1, 1, cphi);
      ret.set(1, 2, -sphi);
      ret.set(2, 0, 0);
      ret.set(2, 1, sphi / ctheta);
      ret.set(2, 2, cphi / ctheta);
      return ret;
   }

   /*
    *  Add random noise to a vector
    */
   void noise(Matrix v, double high, double low) {
      for(int i = 0; i < v.getRowDimension(); i++)
         for(int j = 0; j < v.getColumnDimension(); j++)
            v.set(i, j, v.get(i, j) + Math.random() * (high - low) + low);
   }

   public static void main(String[] args) {
      try {

         FullKalman ahrs = new FullKalman(.001);
         Matrix accl = new Matrix(3,1);
         Matrix pqr = new Matrix(3,1);
         double x = -0.37727;
         int t = 0;

         ahrs.reset();
         accl.set(0, 0, x);
         ahrs.initialize(accl, pqr, 0.0);
         while(++t < 50)
         {
            accl.set(0, 0, x);
            ahrs.imu_update(pqr);
            ahrs.compass_update(0.0, accl);
//         System.out.println(t + " ang = " + ahrs.gcompute_euler_yaw());
         }
      }
      catch(Throwable e) {
         e.printStackTrace(); }
   }
}
